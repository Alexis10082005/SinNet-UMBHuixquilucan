﻿# =====================================================================
#  EduPet AI - INSTALADOR SIN INTERNET
#  Lo abre INSTALAR.bat (como administrador). Instala todo desde el kit:
#   1 Componentes de Windows (VC++)   5 Restaurar la base con los libros
#   2 Driver ODBC 18                  6 Ollama + modelos de la IA
#   3 PHP + app EduPet en C:\EduPet   7 Python + librerias (subir libros)
#   4 SQL Server Express              8 Firewall + iconos del Escritorio
#  Se puede volver a correr: lo que ya este instalado se salta.
# =====================================================================
param([string]$Destino = "C:\EduPet")

$ErrorActionPreference = "Stop"
$kit = Split-Path $PSScriptRoot -Parent
$inst = Join-Path $kit "instaladores"
$errores = New-Object System.Collections.Generic.List[string]

New-Item -ItemType Directory -Force -Path $Destino | Out-Null
Start-Transcript -Path (Join-Path $Destino "instalacion.log") -Append | Out-Null

function Paso($n, $texto) { Write-Host ""; Write-Host "[$n/8] $texto" -ForegroundColor Cyan }
function Ok($texto)       { Write-Host "   OK  $texto" -ForegroundColor Green }
function Falla($texto)    { Write-Host "   XX  $texto" -ForegroundColor Red; $errores.Add($texto) }
function Buscar($sub, $filtro) {
    Get-ChildItem (Join-Path $inst $sub) -Filter $filtro -Recurse -File -ErrorAction SilentlyContinue | Select-Object -First 1
}
# Programas externos (robocopy, php, python): sin que sus avisos detengan el script
function Nativo([scriptblock]$bloque) {
    $antes = $ErrorActionPreference; $ErrorActionPreference = "Continue"
    try { & $bloque } finally { $ErrorActionPreference = $antes }
}
function Ejecutar($archivo, $argumentos) {
    $p = Start-Process -FilePath $archivo -ArgumentList $argumentos -Wait -PassThru
    return $p.ExitCode
}

Write-Host "=============================================" -ForegroundColor Magenta
Write-Host "      EduPet AI - Instalacion sin internet" -ForegroundColor Magenta
Write-Host "      Puede tardar de 20 a 40 minutos." -ForegroundColor Magenta
Write-Host "=============================================" -ForegroundColor Magenta

# ---------------------------------------------------------------- 1. VC++
Paso 1 "Componentes de Windows (Visual C++)..."
try {
    $vc = Buscar "vcredist" "*.exe"
    if ($vc) { $c = Ejecutar $vc.FullName "/install /quiet /norestart"; Ok "Visual C++ listo (codigo $c)." }
    else { Falla "No esta el instalador de Visual C++ en el kit." }
} catch { Falla "Visual C++: $($_.Exception.Message)" }

# ---------------------------------------------------------------- 2. ODBC
Paso 2 "Driver ODBC 18 para SQL Server..."
try {
    if (Test-Path "HKLM:\SOFTWARE\ODBC\ODBCINST.INI\ODBC Driver 18 for SQL Server") { Ok "Ya estaba instalado." }
    else {
        $msi = Buscar "odbc" "*.msi"
        if (-not $msi) { throw "No esta el instalador msodbcsql.msi en el kit." }
        $c = Ejecutar "msiexec.exe" "/i `"$($msi.FullName)`" /quiet /norestart IACCEPTMSODBCSQLLICENSETERMS=YES"
        if ($c -in 0, 3010) { Ok "Driver ODBC instalado." } else { throw "msiexec termino con codigo $c" }
    }
} catch { Falla "ODBC: $($_.Exception.Message)" }

# ---------------------------------------------------------------- 3. PHP + app
Paso 3 "Copiando PHP y la app EduPet a $Destino ..."
try {
    Nativo { robocopy (Join-Path $kit "app") $Destino /E /NFL /NDL /NJH /NJS /NP | Out-Null }
    if ($LASTEXITCODE -ge 8) { throw "robocopy fallo (codigo $LASTEXITCODE)" }
    # php.ini traia rutas de XAMPP: se cambian a la carpeta nueva
    $ini = Join-Path $Destino "php\php.ini"
    if (Test-Path $ini) {
        $texto = [IO.File]::ReadAllText($ini)
        $texto = $texto -replace [regex]::Escape("C:\xampp\php"), "$Destino\php"
        $texto = $texto -replace [regex]::Escape("C:\xampp"), $Destino
        [IO.File]::WriteAllText($ini, $texto)
    }
    New-Item -ItemType Directory -Force -Path (Join-Path $Destino "tmp"), (Join-Path $Destino "tutor_ia\uploads") | Out-Null
    $mods = Nativo { & (Join-Path $Destino "php\php.exe") -m 2>$null }
    if ($mods -contains "pdo_sqlsrv") { Ok "PHP listo con el driver de SQL Server." }
    else { Falla "PHP se copio, pero no cargo pdo_sqlsrv (revisa que el paso 1 y 2 esten bien)." }
} catch { Falla "PHP/app: $($_.Exception.Message)" }

# ---------------------------------------------------------------- 4. SQL Server Express
Paso 4 "SQL Server Express (esto es lo que mas tarda)..."
try {
    if (Get-Service 'MSSQL$SQLEXPRESS' -ErrorAction SilentlyContinue) { Ok "Ya estaba instalado." }
    else {
        $sql = Buscar "sql" "SQLEXPR*.exe"
        if (-not $sql) { throw "No esta SQLEXPR_x64_*.exe en el kit." }
        $tmp = Join-Path $env:TEMP "edupet_sql"
        Write-Host "   ... extrayendo el instalador"
        Ejecutar $sql.FullName "/q /x:`"$tmp`"" | Out-Null
        $usuario = [Security.Principal.WindowsIdentity]::GetCurrent().Name
        Write-Host "   ... instalando (10 a 20 minutos, no cierres esta ventana)"
        $c = Ejecutar (Join-Path $tmp "SETUP.EXE") ("/Q /ACTION=Install /FEATURES=SQLENGINE /INSTANCENAME=SQLEXPRESS " +
             "/SQLSYSADMINACCOUNTS=`"$usuario`" /ADDCURRENTUSERASSQLADMIN=True /SQLSVCSTARTUPTYPE=Automatic " +
             "/IACCEPTSQLSERVERLICENSETERMS /UPDATEENABLED=False /SUPPRESSPRIVACYSTATEMENTNOTICE")
        if (Get-Service 'MSSQL$SQLEXPRESS' -ErrorAction SilentlyContinue) { Ok "SQL Server Express instalado." }
        else { throw "El instalador termino con codigo $c (ver C:\Program Files\Microsoft SQL Server\*\Setup Bootstrap\Log)" }
    }
    Start-Service 'MSSQL$SQLEXPRESS' -ErrorAction SilentlyContinue
} catch { Falla "SQL Server: $($_.Exception.Message)" }

# ---------------------------------------------------------------- 5. Base de datos
Paso 5 "Restaurando la base tutor_ia con los libros..."
try {
    $bakKit = Join-Path $kit "base\tutor_ia.bak"
    if (-not (Test-Path $bakKit)) { throw "No esta base\tutor_ia.bak en el kit." }
    $cn = New-Object System.Data.SqlClient.SqlConnection "Server=.\SQLEXPRESS;Database=master;Integrated Security=True;TrustServerCertificate=True;Connect Timeout=60"
    $cn.Open()
    $cmd = $cn.CreateCommand(); $cmd.CommandTimeout = 0
    $cmd.CommandText = "SELECT CAST(SERVERPROPERTY('InstanceDefaultBackupPath') AS NVARCHAR(400)), CAST(SERVERPROPERTY('InstanceDefaultDataPath') AS NVARCHAR(400)), CAST(SERVERPROPERTY('InstanceDefaultLogPath') AS NVARCHAR(400))"
    $r = $cmd.ExecuteReader(); $null = $r.Read()
    $dirBak = $r.GetString(0); $dirDatos = $r.GetString(1); $dirLog = $r.GetString(2); $r.Close()
    $bak = Join-Path $dirBak "tutor_ia.bak"
    Copy-Item $bakKit $bak -Force

    $cmd.CommandText = "RESTORE FILELISTONLY FROM DISK = N'$bak'"
    $r = $cmd.ExecuteReader(); $mover = @()
    while ($r.Read()) {
        $logico = $r["LogicalName"]; $tipo = $r["Type"]
        $fisico = if ($tipo -eq "L") { Join-Path $dirLog "tutor_ia_log.ldf" } else { Join-Path $dirDatos "tutor_ia.mdf" }
        $mover += "MOVE N'$logico' TO N'$fisico'"
    }
    $r.Close()
    $cmd.CommandText = "IF DB_ID('tutor_ia') IS NOT NULL ALTER DATABASE tutor_ia SET SINGLE_USER WITH ROLLBACK IMMEDIATE"
    $cmd.ExecuteNonQuery() | Out-Null
    $cmd.CommandText = "RESTORE DATABASE tutor_ia FROM DISK = N'$bak' WITH REPLACE, " + ($mover -join ", ")
    $cmd.ExecuteNonQuery() | Out-Null
    $cmd.CommandText = "ALTER DATABASE tutor_ia SET MULTI_USER"
    $cmd.ExecuteNonQuery() | Out-Null
    $cmd.CommandText = "SELECT (SELECT COUNT(*) FROM tutor_ia.dbo.libro), (SELECT COUNT(*) FROM tutor_ia.dbo.fragmento)"
    $r = $cmd.ExecuteReader(); $null = $r.Read(); $libros = $r.GetInt32(0); $frag = $r.GetInt32(1); $r.Close()
    $cn.Close()
    Ok "Base restaurada: $libros libros y $frag fragmentos."
} catch { Falla "Base de datos: $($_.Exception.Message)" }

# ---------------------------------------------------------------- 6. Ollama + modelos
Paso 6 "La IA (Ollama) y sus modelos..."
try {
    $ollamaExe = Join-Path $env:LOCALAPPDATA "Programs\Ollama\ollama.exe"
    if (-not (Get-Command ollama -ErrorAction SilentlyContinue) -and -not (Test-Path $ollamaExe)) {
        $setup = Buscar "ollama" "*.exe"
        if (-not $setup) { throw "No esta OllamaSetup.exe en el kit." }
        Write-Host "   ... instalando Ollama"
        Ejecutar $setup.FullName "/VERYSILENT /SUPPRESSMSGBOXES /NORESTART" | Out-Null
    }
    $destMod = if ($env:OLLAMA_MODELS) { $env:OLLAMA_MODELS } else { Join-Path $env:USERPROFILE ".ollama\models" }
    Nativo { robocopy (Join-Path $kit "modelos") $destMod /E /NFL /NDL /NJH /NJS /NP | Out-Null }
    if ($LASTEXITCODE -ge 8) { throw "No se pudieron copiar los modelos (robocopy $LASTEXITCODE)" }
    Ok "Ollama y modelos listos (en $destMod)."
} catch { Falla "Ollama: $($_.Exception.Message)" }

# ---------------------------------------------------------------- 7. Python
Paso 7 "Python y librerias para que el maestro suba libros..."
try {
    $py = Get-Command python -ErrorAction SilentlyContinue | Where-Object { $_.Source -notlike "*WindowsApps*" } | Select-Object -First 1
    if (-not $py) {
        $pySetup = Buscar "python" "*.exe"
        if (-not $pySetup) { throw "No esta el instalador de Python en el kit." }
        Write-Host "   ... instalando Python"
        Ejecutar $pySetup.FullName "/quiet InstallAllUsers=1 PrependPath=1 Include_test=0" | Out-Null
        $env:Path = [Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [Environment]::GetEnvironmentVariable("Path", "User")
        $py = Get-Command python -ErrorAction SilentlyContinue | Where-Object { $_.Source -notlike "*WindowsApps*" } | Select-Object -First 1
    }
    if (-not $py) { throw "Python no quedo instalado." }
    Nativo { & $py.Source -m pip install --no-index --find-links (Join-Path $kit "python-librerias") pymupdf pyodbc requests --quiet }
    Nativo { & $py.Source -c "import fitz, pyodbc, requests" }
    if ($LASTEXITCODE -eq 0) { Ok "Python listo ($($py.Source))." } else { throw "Las librerias no se instalaron bien." }
} catch { Falla "Python: $($_.Exception.Message)" }

# ---------------------------------------------------------------- 8. Firewall e iconos
Paso 8 "Permiso de red (celulares y tabletas) e iconos del Escritorio..."
try {
    if (-not (Get-NetFirewallRule -DisplayName "EduPet AI" -ErrorAction SilentlyContinue)) {
        New-NetFirewallRule -DisplayName "EduPet AI" -Direction Inbound -Protocol TCP -LocalPort 8000 -Action Allow -Profile Private, Domain | Out-Null
    }
    $win = Join-Path $Destino "tutor_ia\colibri\windows"
    $escritorio = [Environment]::GetFolderPath("CommonDesktopDirectory")
    $w = New-Object -ComObject WScript.Shell
    foreach ($a in @(@("EduPet AI", "Iniciar-EduPet.bat", "Abrir EduPet AI"), @("Apagar EduPet AI", "Apagar-EduPet.bat", "Apagar el servidor de EduPet AI"))) {
        $s = $w.CreateShortcut((Join-Path $escritorio "$($a[0]).lnk"))
        $s.TargetPath = Join-Path $win $a[1]; $s.WorkingDirectory = $win
        $s.IconLocation = Join-Path $win "edupet.ico"; $s.WindowStyle = 7; $s.Description = $a[2]
        $s.Save()
    }
    Ok "Firewall e iconos listos."
} catch { Falla "Firewall/iconos: $($_.Exception.Message)" }

# ---------------------------------------------------------------- Resumen
Write-Host ""
Write-Host "=============================================" -ForegroundColor Magenta
if ($errores.Count -eq 0) {
    Write-Host "   EduPet AI quedo instalado." -ForegroundColor Green
    Write-Host "   Abrelo con el icono 'EduPet AI' del Escritorio." -ForegroundColor Green
} else {
    Write-Host "   La instalacion termino con avisos:" -ForegroundColor Yellow
    $errores | ForEach-Object { Write-Host "   - $_" -ForegroundColor Yellow }
    Write-Host "   Puedes corregir y volver a correr INSTALAR.bat (lo que ya este listo se salta)." -ForegroundColor Yellow
    Write-Host "   Detalle completo en: $Destino\instalacion.log" -ForegroundColor Yellow
}
Write-Host "=============================================" -ForegroundColor Magenta
Stop-Transcript | Out-Null
Read-Host "Presiona Enter para cerrar"
