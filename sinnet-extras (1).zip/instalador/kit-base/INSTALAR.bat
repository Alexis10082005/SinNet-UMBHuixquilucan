@echo off
rem =============================================================
rem  EduPet AI - INSTALADOR (no necesita internet)
rem  Doble clic. Windows pedira permiso de administrador: di que Si.
rem =============================================================
net session >nul 2>&1
if errorlevel 1 (
  powershell -NoProfile -Command "Start-Process '%~f0' -Verb RunAs"
  exit /b
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalador\Instalar-EduPet.ps1"
