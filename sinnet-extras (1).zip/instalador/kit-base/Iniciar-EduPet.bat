@echo off
title SinNet
rem ==============================================================
rem  SinNet - Inicia todo con un doble clic:
rem    1) la IA (Ollama)   2) el backend PHP   3) la app en su ventana
rem ==============================================================

rem La carpeta del proyecto (tutor_ia) esta dos niveles arriba de este archivo
cd /d "%~dp0..\.."

rem PHP: primero el que instala el kit (C:\EduPet\php), luego XAMPP, luego el del sistema
set "PHP=php"
if exist "C:\xampp\php\php.exe" set "PHP=C:\xampp\php\php.exe"
if exist "%CD%\..\php\php.exe" set "PHP=%CD%\..\php\php.exe"

echo.
echo   SinNet - Encendiendo...
echo.

rem ---------- 1) La IA (Ollama) ----------
set "OLLAMA=ollama"
if exist "%LocalAppData%\Programs\Ollama\ollama.exe" set "OLLAMA=%LocalAppData%\Programs\Ollama\ollama.exe"
tasklist /FI "IMAGENAME eq ollama.exe" 2>nul | find /I "ollama.exe" >nul
if errorlevel 1 (
  echo   - Encendiendo la IA ^(Ollama^)...
  start "Ollama" /min "%OLLAMA%" serve
  timeout /t 3 /nobreak >nul
) else (
  echo   - La IA ^(Ollama^) ya estaba encendida.
)

rem ---------- 2) El backend PHP (puerto 8000) ----------
netstat -ano | find ":8000 " | find "LISTENING" >nul
if errorlevel 1 (
  echo   - Encendiendo el servidor de SinNet...
  start "SinNet servidor" /min "%PHP%" -S 0.0.0.0:8000 -d upload_max_filesize=300M -d post_max_size=300M
  timeout /t 2 /nobreak >nul
) else (
  echo   - El servidor de SinNet ya estaba encendido.
)

rem ---------- 3) Abrir la app en su propia ventana ----------
set "URL=http://localhost:8000/colibri/"
set "NAV="
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "NAV=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined NAV if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "NAV=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not defined NAV if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "NAV=%LocalAppData%\Google\Chrome\Application\chrome.exe"
if not defined NAV if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "NAV=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not defined NAV if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "NAV=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"

if defined NAV (
  start "" "%NAV%" --app=%URL% --start-fullscreen
) else (
  start "" %URL%
)

rem ---------- Direccion para celulares y tabletas (mismo Wi-Fi) ----------
echo.
echo   Listo. Para abrir SinNet en celulares y tabletas conectados al mismo Wi-Fi:
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| find "IPv4"') do for /f "tokens=*" %%b in ("%%a") do echo      http://%%b:8000/colibri/
echo.
echo   (Esta ventana se cierra sola. Para apagar todo usa "Apagar SinNet".)
timeout /t 20 >nul
exit
