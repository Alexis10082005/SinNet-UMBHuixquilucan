@echo off
rem Abre Preparar-Kit.ps1 como administrador.
rem Para guardar el kit en una USB, cambia la ruta de -Destino (ejemplo: E:\EduPet-Kit).
net session >nul 2>&1
if errorlevel 1 (
  powershell -NoProfile -Command "Start-Process '%~f0' -Verb RunAs"
  exit /b
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Preparar-Kit.ps1" -Destino "%USERPROFILE%\Desktop\EduPet-Kit"
