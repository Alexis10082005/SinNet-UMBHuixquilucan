﻿# =====================================================================
#  EduPet AI - PREPARAR EL KIT DE INSTALACION
#  Se corre UNA vez en TU computadora (la que ya funciona) y CON internet.
#  Junta en una carpeta (o USB) todo lo necesario para instalar EduPet AI
#  en otra computadora SIN internet.
#
#  Uso:  clic derecho en Preparar-Kit.bat -> Ejecutar como administrador
#        (o: Preparar-Kit.ps1 -Destino E:\EduPet-Kit  para guardarlo en la USB)
# =====================================================================
param(
    [string]$Destino   = "$env:USERPROFILE\Desktop\EduPet-Kit",
    [string]$Proyecto  = "C:\xampp\htdocs\tutor_ia",
    [string]$CarpetaPhp = "C:\xampp\php",
    [string]$ServidorSql = ".\SQLEXPRESS",
    [string]$BaseDatos = "tutor_ia",
    [string[]]$Modelos = @("qwen2.5:3b", "bge-m3")
)

$ErrorActionPreference = "Stop"
$aqui = $PSScriptRoot
$problemas = New-Object System.Collections.Generic.List[string]

function Nativo([scriptblock]$bloque) {
    $antes = $ErrorActionPreference; $ErrorActionPreference = "Continue"
    try { & $bloque } finally { $ErrorActionPreference = $antes }
}
function Paso($n, $texto) { Write-Host ""; Write-Host "[$n/8] $texto" -ForegroundColor Cyan }
function Ok($texto)       { Write-Host "   OK  $texto" -ForegroundColor Green }
function Aviso($texto)    { Write-Host "   !!  $texto" -ForegroundColor Yellow; $problemas.Add($texto) }

Write-Host "=============================================" -ForegroundColor Magenta
Write-Host "   EduPet AI - Preparando el kit de instalacion" -ForegroundColor Magenta
Write-Host "   Destino: $Destino" -ForegroundColor Magenta
Write-Host "=============================================" -ForegroundColor Magenta

$dirInst  = Join-Path $Destino "instaladores"
$dirApp   = Join-Path $Destino "app"
$dirMod   = Join-Path $Destino "modelos"
$dirBase  = Join-Path $Destino "base"
$dirWheel = Join-Path $Destino "python-librerias"
foreach ($d in @($Destino, $dirInst, $dirApp, $dirMod, $dirBase, $dirWheel)) {
    New-Item -ItemType Directory -Force -Path $d | Out-Null
}

# ---------------------------------------------------------------- 1. App
Paso 1 "Copiando el proyecto EduPet (tutor_ia)..."
if (-not (Test-Path $Proyecto)) { throw "No encuentro la carpeta del proyecto: $Proyecto" }
Nativo { robocopy $Proyecto (Join-Path $dirApp "tutor_ia") /E /XD uploads .git node_modules /NFL /NDL /NJH /NJS /NP | Out-Null }
# Lanzador actualizado (sabe usar el PHP portatil de C:\EduPet\php)
$lanzador = Join-Path $aqui "kit-base\Iniciar-EduPet.bat"
$destLanz = Join-Path $dirApp "tutor_ia\colibri\windows"
if ((Test-Path $lanzador) -and (Test-Path $destLanz)) { Copy-Item $lanzador $destLanz -Force }
if (Test-Path (Join-Path $dirApp "tutor_ia\colibri\index.html")) { Ok "Proyecto copiado (con la app Colibri)." }
else { Aviso "El proyecto no tiene la carpeta colibri. Instala colibri.zip antes de preparar el kit." }

# ---------------------------------------------------------------- 2. PHP
Paso 2 "Copiando PHP con los drivers de SQL Server..."
if (-not (Test-Path (Join-Path $CarpetaPhp "php.exe"))) { throw "No encuentro PHP en $CarpetaPhp" }
Nativo { robocopy $CarpetaPhp (Join-Path $dirApp "php") /E /XD tmp logs /NFL /NDL /NJH /NJS /NP | Out-Null }
$mods = Nativo { & (Join-Path $CarpetaPhp "php.exe") -m 2>$null }
if ($mods -contains "pdo_sqlsrv") { Ok "PHP copiado (con pdo_sqlsrv)." } else { Aviso "Tu PHP no tiene pdo_sqlsrv activo." }

# ---------------------------------------------------------------- 3. Modelos de IA
Paso 3 "Copiando los modelos de la IA ($($Modelos -join ', '))..."
$origenMod = if ($env:OLLAMA_MODELS) { $env:OLLAMA_MODELS } else { Join-Path $env:USERPROFILE ".ollama\models" }
foreach ($m in $Modelos) {
    $nombre, $etiqueta = $m.Split(":"); if (-not $etiqueta) { $etiqueta = "latest" }
    $manifiesto = Join-Path $origenMod "manifests\registry.ollama.ai\library\$nombre\$etiqueta"
    if (-not (Test-Path $manifiesto)) { Aviso "No encontre el modelo $m. Descargalo con: ollama pull $m"; continue }
    $destManif = Join-Path $dirMod "manifests\registry.ollama.ai\library\$nombre"
    New-Item -ItemType Directory -Force -Path $destManif | Out-Null
    Copy-Item $manifiesto (Join-Path $destManif $etiqueta) -Force
    $json = Get-Content $manifiesto -Raw | ConvertFrom-Json
    $capas = @($json.config) + @($json.layers)
    New-Item -ItemType Directory -Force -Path (Join-Path $dirMod "blobs") | Out-Null
    foreach ($c in $capas) {
        $archivo = $c.digest.Replace(":", "-")
        $src = Join-Path $origenMod "blobs\$archivo"
        $dst = Join-Path $dirMod "blobs\$archivo"
        if (-not (Test-Path $dst)) { Copy-Item $src $dst }
    }
    Ok "Modelo $m copiado."
}

# ---------------------------------------------------------------- 4. Base de datos
Paso 4 "Respaldando la base de datos $BaseDatos (con los libros)..."
try {
    $cn = New-Object System.Data.SqlClient.SqlConnection "Server=$ServidorSql;Database=master;Integrated Security=True;TrustServerCertificate=True"
    $cn.Open()
    $cmd = $cn.CreateCommand(); $cmd.CommandTimeout = 0
    $cmd.CommandText = "SELECT CAST(SERVERPROPERTY('InstanceDefaultBackupPath') AS NVARCHAR(400))"
    $carpetaRespaldo = [string]$cmd.ExecuteScalar()
    $bak = Join-Path $carpetaRespaldo "tutor_ia_kit.bak"
    $cmd.CommandText = "BACKUP DATABASE [$BaseDatos] TO DISK = N'$bak' WITH INIT, COPY_ONLY"
    $cmd.ExecuteNonQuery() | Out-Null
    $cn.Close()
    Copy-Item $bak (Join-Path $dirBase "tutor_ia.bak") -Force
    Ok "Respaldo listo."
} catch { Aviso "No se pudo respaldar la base: $($_.Exception.Message)" }

# ---------------------------------------------------------------- 5. Instaladores (winget)
Paso 5 "Descargando instaladores (necesita internet)..."
function Bajar($id, $sub) {
    $dir = Join-Path $dirInst $sub
    if (Get-ChildItem $dir -File -ErrorAction SilentlyContinue | Where-Object { $_.Extension -in ".exe", ".msi" }) { Ok "$id ya estaba descargado."; return }
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    Nativo { winget download --id $id -e --download-directory $dir --accept-source-agreements --accept-package-agreements --disable-interactivity | Out-Null }
    if (Get-ChildItem $dir -File | Where-Object { $_.Extension -in ".exe", ".msi" }) { Ok "$id descargado." }
    else { Aviso "No se pudo descargar $id. Bajalo a mano y ponlo en: $dir" }
}
if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
    Aviso "No esta winget. Descarga a mano los instaladores (ver LEEME)."
} else {
    Bajar "Microsoft.VCRedist.2015+.x64" "vcredist"
    Bajar "Microsoft.msodbcsql.18"      "odbc"
    Bajar "Ollama.Ollama"               "ollama"
    $pyVer = (Nativo { & python -c "import sys;print(f'{sys.version_info[0]}.{sys.version_info[1]}')" }).Trim()
    Bajar "Python.Python.$pyVer"        "python"
    Bajar "Microsoft.SQLServer.2022.Express" "sql-descargador"
}

# ---------------------------------------------------------------- 6. SQL Server Express (instalador completo, sin internet)
Paso 6 "Descargando SQL Server Express completo (para instalar sin internet)..."
$dirSql = Join-Path $dirInst "sql"
New-Item -ItemType Directory -Force -Path $dirSql | Out-Null
if (Get-ChildItem $dirSql -Filter "SQLEXPR*.exe" -Recurse -ErrorAction SilentlyContinue) { Ok "SQL Server Express ya estaba descargado." }
else {
    $ssei = Get-ChildItem (Join-Path $dirInst "sql-descargador") -Filter "*.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($ssei) {
        Start-Process $ssei.FullName -ArgumentList "/ACTION=Download", "/MEDIAPATH=`"$dirSql`"", "/MEDIATYPE=Core", "/QUIET" -Wait
        if (Get-ChildItem $dirSql -Filter "SQLEXPR*.exe" -Recurse) { Ok "SQL Server Express descargado." }
        else { Aviso "No se descargo SQL Server Express. Abre $($ssei.Name), elige 'Descargar medios' > 'Express Core' y guardalo en $dirSql" }
    } else { Aviso "Falta el descargador de SQL Server Express." }
}

# ---------------------------------------------------------------- 7. Librerias de Python
Paso 7 "Descargando las librerias de Python para subir libros..."
try {
    Nativo { & python -m pip download pymupdf pyodbc requests -d $dirWheel --only-binary=:all: --quiet }
    if (Get-ChildItem $dirWheel -Filter "pyodbc*") { Ok "Librerias de Python listas." } else { Aviso "No se bajaron las librerias de Python." }
} catch { Aviso "No se pudieron bajar las librerias de Python: $($_.Exception.Message)" }

# ---------------------------------------------------------------- 8. Instalador
Paso 8 "Copiando el instalador al kit..."
Copy-Item (Join-Path $aqui "kit-base\*") $Destino -Recurse -Force
Remove-Item (Join-Path $Destino "Iniciar-EduPet.bat") -ErrorAction SilentlyContinue
Ok "Listo."

$tam = (Get-ChildItem $Destino -Recurse -File | Measure-Object Length -Sum).Sum / 1GB
Write-Host ""
Write-Host "=============================================" -ForegroundColor Magenta
Write-Host ("   Kit terminado: {0}  ({1:N1} GB)" -f $Destino, $tam) -ForegroundColor Magenta
Write-Host "   En la otra computadora: doble clic en INSTALAR.bat" -ForegroundColor Magenta
Write-Host "=============================================" -ForegroundColor Magenta
if ($problemas.Count) {
    Write-Host ""; Write-Host "Revisa estos avisos antes de usar el kit:" -ForegroundColor Yellow
    $problemas | ForEach-Object { Write-Host "  - $_" -ForegroundColor Yellow }
}
Write-Host ""; Read-Host "Presiona Enter para cerrar"
