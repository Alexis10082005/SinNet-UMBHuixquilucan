/* =====================================================================
   tutor_ia - Esquema del prototipo (versión compatible, SQL Server 2016 o superior)
   La búsqueda por similitud se hace en el backend (ver buscar_fragmentos.py).
   Tutor IA local para educación básica (RAG).

   Convención: solo llaves primarias; sin llaves foráneas ni otras
   restricciones. Las relaciones se indican en comentarios (-> tabla.col).
   Se puede ejecutar varias veces sin romper nada.

   Archivo en UTF-8 sin BOM:
     sqlcmd -S localhost -E -f 65001 -i 01_esquema_sqlserver_compat.sql
   ===================================================================== */

IF DB_ID(N'tutor_ia') IS NULL
    CREATE DATABASE tutor_ia COLLATE Modern_Spanish_100_CI_AI;
GO

USE tutor_ia;
GO

/* ---------------------------------------------------------------------
   CATÁLOGOS
   --------------------------------------------------------------------- */

IF OBJECT_ID(N'dbo.nivel') IS NULL
CREATE TABLE dbo.nivel (
    nivel_id INT IDENTITY(1,1) PRIMARY KEY,
    nombre   NVARCHAR(50)                      -- Primaria, Secundaria
);

IF OBJECT_ID(N'dbo.grado') IS NULL
CREATE TABLE dbo.grado (
    grado_id INT IDENTITY(1,1) PRIMARY KEY,
    nivel_id INT,                              -- -> nivel.nivel_id
    numero   TINYINT,                          -- 1..6
    nombre   NVARCHAR(50)                      -- "5.º de primaria"
);

IF OBJECT_ID(N'dbo.materia') IS NULL
CREATE TABLE dbo.materia (
    materia_id INT IDENTITY(1,1) PRIMARY KEY,
    nombre     NVARCHAR(100)                   -- Español, Matemáticas
);

/* ---------------------------------------------------------------------
   CONTENIDO (lo llena el script de ingesta)
   --------------------------------------------------------------------- */

IF OBJECT_ID(N'dbo.libro') IS NULL
CREATE TABLE dbo.libro (
    libro_id       INT IDENTITY(1,1) PRIMARY KEY,
    grado_id       INT,                        -- -> grado.grado_id
    materia_id     INT,                        -- -> materia.materia_id
    titulo         NVARCHAR(300),
    editorial      NVARCHAR(100),
    anio_edicion   SMALLINT,
    fuente_url     NVARCHAR(500),
    archivo_nombre NVARCHAR(260),
    archivo_hash   CHAR(64),                   -- SHA-256 del PDF (evita ingestas duplicadas)
    total_paginas  INT,
    fecha_ingesta  DATETIME2
);

IF OBJECT_ID(N'dbo.tema') IS NULL
CREATE TABLE dbo.tema (                        -- índice jerárquico del libro (bloques, lecciones)
    tema_id         INT IDENTITY(1,1) PRIMARY KEY,
    libro_id        INT,                       -- -> libro.libro_id
    tema_padre_id   INT,                       -- -> tema.tema_id (NULL si es raíz)
    titulo          NVARCHAR(300),
    nivel_jerarquia TINYINT,                   -- 1 = capítulo/bloque, 2 = lección, ...
    pagina_inicio   INT,
    pagina_fin      INT,
    orden           INT
);

IF OBJECT_ID(N'dbo.fragmento') IS NULL
CREATE TABLE dbo.fragmento (                   -- trozo de ~350 palabras que se busca y se pasa al modelo
    fragmento_id     BIGINT IDENTITY(1,1) PRIMARY KEY,
    libro_id         INT,                      -- -> libro.libro_id
    tema_id          INT,                      -- -> tema.tema_id (puede ser NULL)
    grado_id         INT,                      -- copia de libro.grado_id (filtro rápido)
    materia_id       INT,                      -- copia de libro.materia_id (filtro rápido)
    pagina_inicio    INT,
    pagina_fin       INT,
    orden            INT,                      -- posición dentro del libro
    tipo             NVARCHAR(30),             -- 'texto' por ahora; luego 'ejercicio', 'definicion'...
    texto            NVARCHAR(MAX),
    num_palabras     INT,
    texto_hash       CHAR(64),
    embedding        VARBINARY(MAX),           -- bge-m3: 1024 float32 little-endian (4096 bytes)
    modelo_embedding NVARCHAR(100)
);

/* ---------------------------------------------------------------------
   USO DE LA APP
   --------------------------------------------------------------------- */

IF OBJECT_ID(N'dbo.usuario') IS NULL
CREATE TABLE dbo.usuario (
    usuario_id     INT IDENTITY(1,1) PRIMARY KEY,
    nombre         NVARCHAR(100),
    grado_id       INT,                        -- -> grado.grado_id
    fecha_registro DATETIME2
);

IF OBJECT_ID(N'dbo.conversacion') IS NULL
CREATE TABLE dbo.conversacion (
    conversacion_id INT IDENTITY(1,1) PRIMARY KEY,
    usuario_id      INT,                       -- -> usuario.usuario_id
    grado_id        INT,                       -- -> grado.grado_id
    materia_id      INT,                       -- -> materia.materia_id (NULL = todas)
    titulo          NVARCHAR(200),
    fecha_inicio    DATETIME2
);

IF OBJECT_ID(N'dbo.mensaje') IS NULL
CREATE TABLE dbo.mensaje (
    mensaje_id      BIGINT IDENTITY(1,1) PRIMARY KEY,
    conversacion_id INT,                       -- -> conversacion.conversacion_id
    rol             NVARCHAR(20),              -- 'alumno' | 'tutor'
    contenido       NVARCHAR(MAX),
    fecha           DATETIME2,
    modelo_llm      NVARCHAR(100),             -- p. ej. 'llama3.1:8b'
    ms_respuesta    INT,
    util            BIT                        -- retroalimentación del alumno (NULL = sin voto)
);

IF OBJECT_ID(N'dbo.mensaje_fuente') IS NULL
CREATE TABLE dbo.mensaje_fuente (              -- fragmentos que sustentaron cada respuesta
    mensaje_id   BIGINT,                       -- -> mensaje.mensaje_id
    fragmento_id BIGINT,                       -- -> fragmento.fragmento_id
    distancia    FLOAT,
    PRIMARY KEY (mensaje_id, fragmento_id)
);

IF OBJECT_ID(N'dbo.ingesta_log') IS NULL
CREATE TABLE dbo.ingesta_log (
    ingesta_id  INT IDENTITY(1,1) PRIMARY KEY,
    libro_id    INT,                           -- -> libro.libro_id
    fecha       DATETIME2,
    temas       INT,
    fragmentos  INT,
    estado      NVARCHAR(20),                  -- 'ok' | 'error'
    nota        NVARCHAR(500)
);
GO

/* ---------------------------------------------------------------------
   ÍNDICES (no son restricciones; solo aceleran filtros frecuentes)
   --------------------------------------------------------------------- */

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'ix_fragmento_filtro' AND object_id = OBJECT_ID(N'dbo.fragmento'))
    CREATE INDEX ix_fragmento_filtro ON dbo.fragmento (grado_id, materia_id);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'ix_tema_libro' AND object_id = OBJECT_ID(N'dbo.tema'))
    CREATE INDEX ix_tema_libro ON dbo.tema (libro_id);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'ix_mensaje_conversacion' AND object_id = OBJECT_ID(N'dbo.mensaje'))
    CREATE INDEX ix_mensaje_conversacion ON dbo.mensaje (conversacion_id);
GO

/* ---------------------------------------------------------------------
   DATOS INICIALES
   --------------------------------------------------------------------- */

IF NOT EXISTS (SELECT 1 FROM dbo.nivel)
    INSERT INTO dbo.nivel (nombre) VALUES (N'Primaria'), (N'Secundaria');

IF NOT EXISTS (SELECT 1 FROM dbo.materia)
    INSERT INTO dbo.materia (nombre) VALUES (N'Español'), (N'Matemáticas');

IF NOT EXISTS (SELECT 1 FROM dbo.grado)
    INSERT INTO dbo.grado (nivel_id, numero, nombre)
    SELECT n.nivel_id, v.numero, CONCAT(v.numero, N'.º de ', LOWER(n.nombre))
    FROM (VALUES (N'Primaria', 5), (N'Primaria', 6),
                 (N'Secundaria', 1), (N'Secundaria', 2), (N'Secundaria', 3)) AS v(nivel, numero)
    JOIN dbo.nivel n ON n.nombre = v.nivel;
GO

/* ---------------------------------------------------------------------
   PROCEDIMIENTOS PARA EL EQUIPO DE LA APP
   --------------------------------------------------------------------- */

/* Guarda un mensaje y, si es respuesta del tutor, los fragmentos usados.
   @fuentes_json: '[{"fragmento_id":12,"distancia":0.21},{"fragmento_id":40,"distancia":0.25}]'
   Devuelve el mensaje_id creado. */
CREATE OR ALTER PROCEDURE dbo.sp_guardar_mensaje
    @conversacion_id INT,
    @rol             NVARCHAR(20),
    @contenido       NVARCHAR(MAX),
    @modelo_llm      NVARCHAR(100) = NULL,
    @ms_respuesta    INT = NULL,
    @fuentes_json    NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO dbo.mensaje (conversacion_id, rol, contenido, fecha, modelo_llm, ms_respuesta)
    VALUES (@conversacion_id, @rol, @contenido, SYSUTCDATETIME(), @modelo_llm, @ms_respuesta);

    DECLARE @mensaje_id BIGINT = SCOPE_IDENTITY();

    IF @fuentes_json IS NOT NULL
        INSERT INTO dbo.mensaje_fuente (mensaje_id, fragmento_id, distancia)
        SELECT @mensaje_id, fragmento_id, distancia
        FROM OPENJSON(@fuentes_json)
             WITH (fragmento_id BIGINT '$.fragmento_id', distancia FLOAT '$.distancia');

    SELECT @mensaje_id AS mensaje_id;
END
GO

/* ---------------------------------------------------------------------
   OPCIONAL: búsqueda por palabras clave (requiere Full-Text Search
   instalado). Útil para probar antes de tener embeddings.

   CREATE FULLTEXT CATALOG ft_tutor AS DEFAULT;
   CREATE FULLTEXT INDEX ON dbo.fragmento (texto LANGUAGE 3082)
       KEY INDEX PK__fragment__<sufijo_generado>;   -- consultar el nombre real de la PK con sp_help
   --------------------------------------------------------------------- */
