# SinNet · Tutor con IA sin internet 🐦

Tutor con inteligencia artificial para escuelas sin internet. Una sola laptop
con Windows corre todo y los alumnos se conectan desde celulares, tabletas o
computadoras por el Wi-Fi local. El tutor ("el colibrí") contesta usando los
libros de texto de la SEP y dice de qué libro y página sacó la respuesta.

## Cómo funciona

```
App (HTML/CSS/JS)  →  Backend PHP  →  SQL Server (libros en fragmentos)
                           ↓
                    Ollama (IA local): qwen2.5:3b + bge-m3
```

1. El alumno pregunta en el chat.
2. El backend saca el *embedding* de la pregunta (bge-m3) y busca en SQL Server
   los fragmentos de libro más parecidos (distancia coseno, top 3, umbral 0.55).
3. La IA (qwen2.5:3b) contesta usando solo esos fragmentos.
4. Se guarda la conversación y se devuelve la respuesta con libro y página.

## Partes del proyecto

| Carpeta / archivo | Qué es |
|---|---|
| `colibri/` | App principal (alumno y maestro), diseño responsivo |
| `colibri/windows/` | Lanzadores para Windows (encender, apagar, accesos directos) |
| `app/`, `profesor/` | Primera versión sencilla de la app |
| `database.php` | Conexión a SQL Server (PDO `pdo_sqlsrv`) |
| `grados.php`, `materias.php`, `usuarios.php`, `conversaciones.php` | API de catálogos y usuarios |
| `mensajes.php` | El tutor: búsqueda en libros (RAG) + respuesta de la IA |
| `libros.php`, `subir_libro.php`, `progreso.php`, `borrar_libro.php` | Apartado del maestro: subir, ver avance y borrar libros |
| `ingesta/` | Scripts de Python que parten los PDF y guardan los embeddings |
| `base/` | Esquema de la base de datos `tutor_ia` |
| `instalador/` | Kit para instalar todo en otra computadora sin internet |

## Requisitos

- Windows 10/11, 8 GB de RAM
- PHP 8.2 con `pdo_sqlsrv` y ODBC Driver 18 para SQL Server
- SQL Server 2022 Express (instancia `.\SQLEXPRESS`, autenticación de Windows)
- Ollama con `qwen2.5:3b` y `bge-m3`
- Python 3 con `pymupdf pyodbc requests` (solo para subir libros)

## Cómo correrlo

```
ollama pull qwen2.5:3b
ollama pull bge-m3
cd C:\xampp\htdocs\tutor_ia
C:\xampp\php\php.exe -S 0.0.0.0:8000 -d upload_max_filesize=300M -d post_max_size=300M
```

Abrir `http://localhost:8000/colibri/`. Desde otro dispositivo en el mismo Wi-Fi:
`http://IP-DE-LA-LAPTOP:8000/colibri/`.

La base de datos con los libros ya cargados y los modelos de IA no están en
el repositorio porque pesan varios GB; el instalador (`instalador/`) los junta
en una USB.

## Equipo

Proyecto de hackatón · 2026
